import time as t
from random import randrange


def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2
        left = arr[:mid]
        right = arr[mid:]

        # recursive calls
        merge_sort(left)
        merge_sort(right)

        # merge
        i = j = k = 0
        while i < len(left) and j < len(right):
            if left[i] < right[j]:
                arr[k] = left[i]
                i += 1
            else:
                arr[k] = right[j]
                j += 1
            k += 1

        # rest of the elements of two parts
        while i < len(left):
            arr[k] = left[i]
            i += 1
            k += 1

        while j < len(right):
            arr[k] = right[j]
            j += 1
            k += 1


def insertion_sort(arr):
    for i in range(1, len(arr)):
        current = arr[i]
        j = i - 1
        while j >= 0 and current < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current


my_array = list()

# make a random array
for item in range(30000):
    my_array.append(randrange(-10000, 10000))

# make a copy of array for second sort
my_array_c = list(my_array)

# sort using merge algo
tic = t.perf_counter()
merge_sort(my_array)
tac = t.perf_counter()

merge_time = tac - tic

# sort using insertion sort
tic = t.perf_counter()
insertion_sort(my_array_c)
tac = t.perf_counter()

insertion_time = tac - tic

# results
print("insertion sort timer:", round(insertion_time, 2))
print("merge sort timer:", round(merge_time, 2))
